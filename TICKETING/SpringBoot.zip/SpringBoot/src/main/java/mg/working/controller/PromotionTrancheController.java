package mg.working.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import mg.working.model.PromotionTranche;
import mg.working.repository.PromotionTrancheRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class PromotionTrancheController {
    @Autowired 
    private PromotionTrancheRepository promTrancheRepo  ; 

    @PostMapping("/updatePromo")
    public String updatePromotion(@RequestParam int idPromoAdult, 
                                  @RequestParam int pourcentageAdult, 
                                  @RequestParam int idPromoEnfant , 
                                  @RequestParam int pourcentageEnfant ) 
    {
        PromotionTranche promoTranche = new PromotionTranche() ; 
        promoTranche.setIdPromotion(idPromoAdult);
        promoTranche.setPourcentage(pourcentageAdult); 
        promTrancheRepo.updatePromotionTranche(promoTranche) ; 

        promoTranche.setIdPromotion(idPromoEnfant);
        promoTranche.setPourcentage(pourcentageEnfant); 
        promTrancheRepo.updatePromotionTranche(promoTranche) ; 
        
        return "UpdatePromo";
    }

    @GetMapping("/updatePromotion")
    public String redirectPage() 
    {
        return "UpdatePromo";
    }
    
}
