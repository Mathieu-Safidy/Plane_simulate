package mg.working.model;


public class PromotionTranche {
    int idPromotion;
    String libelle;
    int pourcentage;

    // Constructeurs
    public PromotionTranche() {}

    public PromotionTranche( int idPromotion , String libelle, int pourcentage) {
        this.idPromotion = idPromotion ;
        this.libelle = libelle;
        this.pourcentage = pourcentage;
    }

    // Getters et Setters
    public int getIdPromotion() {
        return idPromotion;
    }

    public void setIdPromotion(int idPromotion) {
        this.idPromotion = idPromotion;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getPourcentage() {
        return pourcentage;
    }

    public void setPourcentage(int pourcentage) {
        this.pourcentage = pourcentage;
    }
}
