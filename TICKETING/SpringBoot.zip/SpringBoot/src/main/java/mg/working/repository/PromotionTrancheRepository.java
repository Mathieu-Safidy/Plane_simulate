package mg.working.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import mg.working.model.PromotionTranche;

@Repository
public class PromotionTrancheRepository {

    private final JdbcTemplate jdbcTemplate;

    public PromotionTrancheRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int insertPromotionTranche(PromotionTranche promotion) {
        String sql = "INSERT INTO PromotionTranche (libelle, pourcentage) VALUES (?, ?)";
        return jdbcTemplate.queryForObject(sql, Integer.class, promotion.getLibelle(), promotion.getPourcentage());
    }
    // Méthode pour mettre à jour une promotion
    public int updatePromotionTranche(PromotionTranche promotion) {
        String sql = "UPDATE PromotionTranche SET pourcentage = ? WHERE idPromotion = ?";
        return jdbcTemplate.update(sql, promotion.getPourcentage(), promotion.getIdPromotion());
    }
}
